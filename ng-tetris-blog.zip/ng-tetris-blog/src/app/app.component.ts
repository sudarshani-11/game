import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <game-board></game-board>
  `,
  styles: []
})
export class AppComponent {
  title = 'ng-tetris';
}
